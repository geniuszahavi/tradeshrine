<header class="header-section header-section--style2">
  <div class="header-bottom">
    <div class="container">
      <div class="header-wrapper">
        <div class="logo">
          <a href="index.php">
            <img class="dark" src="assets/images/logo/bobis.png" width="150" alt="logo">
          </a>
        </div>
        <div class="menu-area">
          <ul class="menu menu--style1">
            <li>
              <a href="index.php">Home </a>
             
            </li>
            <li>
              <a href="services.php">Services</a>
              
            </li>
            <li>
                <a href="about.php">About Us</a>
              
            </li>
                           
           


            
            <li>
              <a href="contact.php">Contact Us</a>
            </li>
          </ul>

        </div>
        <div class="header-action">
          <div class="menu-area">
            <div class="header-btn">
              <a href="signup.php" class="trk-btn trk-btn--border trk-btn--primary">
                <span class="text-white">Get Started</span>
              </a>
            </div>

            <!-- toggle icons -->
            <div class="header-bar d-lg-none header-bar--style1">
              <span></span>
              <span></span>
              <span></span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</header>